# Voice-Vision AI System

End-to-end multimodal pipeline integrating voice, vision, and language.