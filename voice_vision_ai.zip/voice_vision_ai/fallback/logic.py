def handle_missing(object_name):
    return f"Sorry, I couldn't find the {object_name} in the image."